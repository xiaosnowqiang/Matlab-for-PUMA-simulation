%%Use the MATLAB Robotics Toolbox to show some example part.
child=figure('name','�Ӵ��ڣ������˹����䲿��','menubar','none','numbertitle','off','position',[320 50 900 700]);
posedescription=uicontrol('style','pushbutton','position',[20 100 80 20],'String','����任',...
'callback',@pose_description_button_press);  
buildrobot=uicontrol('style','pushbutton','position',[20 60 80 20],'String','����762ģ��',...
'callback',@build_robot_button_press);
trajectoryplan=uicontrol('style','pushbutton','position',[20 20 80 20],'String','�켣�滮1',...
'callback',@trajectory_plan_button_press);   
runplan=uicontrol('style','pushbutton','position',[105 100 80 20],'String','�켣�滮2',...
'callback',@run_plan_button_press);   
cubicplan=uicontrol('style','pushbutton','position',[105 60 80 20],'String','���ζ���ʽ��ֵ',...
'callback',@cubic_plan_button_press);   
fifthorderplan=uicontrol('style','pushbutton','position',[105 20 80 20],'String','��ζ���ʽ��ֵ',...
'callback',@fifthorder_plan_button_press);
leapmotioncontrol=uicontrol('style','pushbutton','position',[200 60 80 20],'String','LeapMotion',...
'callback',@leapmotion_control_button_press);
%
%% Some example from matlab robotics  toolbox.
function pose_description_button_press(h,dummy)
    %Execute this program
     cla(gcf)
   
    PoseDescription 
end
%% 
function build_robot_button_press(h,dummy)
    %Execute this program
    cla(gcf)
    BuildTheRobot1
    if trajectory_plan_button_press 
     return
    end
end
%% 
function trajectory_plan_button_press(h,dummy)
    %Execute this program
    cla(gcf)
   TrajectoryPlan
end
%% 
function run_plan_button_press(h,dummy)
    %Execute this program
    cla(gcf)
   RunPlan
end
%% 
function cubic_plan_button_press(h,dummy)
    %Execute this program
    cla(gcf)
    Cubic
end
%% 
function fifthorder_plan_button_press(h,dummy)
    %Execute this program
  Fifth 
end
%% 
function leapmotion_control_button_press(h,dummy)
    %Execute this program
    clc
    clear
    close all
   Puma_Simulation;
   msgbox('leap motion���Ӻ��ˣ�û��Ctrl+C�˳�����������');
   ChildWscreen;
   Moveit
   if pose_description_button_press||build_robot_button_press||trajectory_plan_button_press||run_plan_button_press
     return
   end
    
end



