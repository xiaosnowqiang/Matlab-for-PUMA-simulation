%If you want more detail,please visit the web:https://blog.csdn.net/jldemanman/article/details/79287766
clear;
clc;
q_array=[0,50,150,100,0];%ָ����ֹλ��
t_array=[0,2,4,8,10];%ָ����ֹʱ��
v_array=[0,10,20,-15,0];%ָ����ֹ�ٶ�
t=[t_array(1)];q=[q_array(1)];v=[v_array(1)];a=[0];%��ʼ״̬
for i=1:1:length(q_array)-1;%ÿһ�ι滮��ʱ��
     a0=q_array(i);
     a1=v_array(i);
     a2=(3/(t_array(i+1)-t_array(i))^2)*(q_array(i+1)-q_array(i))-(1/(t_array(i+1)-t_array(i)))*(2*v_array(i)+v_array(i+1));
     a3=(2/(t_array(i+1)-t_array(i))^3)*(q_array(i)-q_array(i+1))+(1/(t_array(i+1)-t_array(i))^2)*(v_array(i)+v_array(i+1));%�������ζ���ʽϵ�� 
     ti=t_array(i)+0.001:0.001:t_array(i+1);
     qi=a0+a1*(ti-t_array(i))+a2*(ti-t_array(i)).^2+a3*(ti-t_array(i)).^3;
     vi=a1+2*a2*(ti-t_array(i))+3*a3*(ti-t_array(i)).^2;
     ai=2*a2+6*a3*(ti-t_array(i));
     t=[t,ti];q=[q,qi];v=[v,vi];a=[a,ai];
end
subplot(3,1,1),plot(t,q,'r'),xlabel('t'),ylabel('position');grid on;
subplot(3,1,2),plot(t,v,'b'),xlabel('t'),ylabel('velocity');grid on;
subplot(3,1,3),plot(t,a,'g'),xlabel('t'),ylabel('accelerate');grid on;