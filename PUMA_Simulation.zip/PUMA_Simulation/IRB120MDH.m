
%        theta  d        a        alpha    offset
L1 = Link([pi     0.290       0        0     0],'modified');
L2 = Link([pi/2     0   0    pi/2        0],'modified');
L3 = Link([0     0       0.270    0     0],'modified');
L4 = Link([0     0.302       0.070        -pi/2    0],'modified');
L5 = Link([-pi     0       0        pi/2     0],'modified');
L6 = Link([0     0.072       0       pi/2       0],'modified');
robot=SerialLink([L1 L2 L3 L4 L5 L6],'name','IRB 120');
figure
teach(robot)