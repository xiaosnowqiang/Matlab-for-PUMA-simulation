function [x,y,z]=GetXYZdata(~)
%Bucle principal
while true
  metaData =  matleap(1); %Agafar dades
  if ~isempty(metaData.pointables) %Comprobaci�� si detecta dades
      x=metaData.pointables(3).position(1);
      y=metaData.pointables(3).position(2);
      z=metaData.pointables(3).position(3);
      x = round(x);
      y = round(y);
      z = round(z);
      %Actualitzar els gr��fics
      subplot(2,1,1);
      hold on
      plot(x,y,'+r','LineWidth',2),axis([-300 300 0 500]);
      %text(x,y,['(' num2str(x) ',' num2str(y) ')']);
      xlabel('x');
      ylabel('y');
      grid on;
      subplot(2,1,2);
      hold on
      plot(x,z,'+g','LineWidth',2),axis([-300 300 -400 400]);
      %text(x,z,['(' num2str(x) ',' num2str(z) ')']);
      xlabel('x');
      ylabel('z');
      grid on;
      drawnow;
  end
  pause(0.001);  
end
end