function [angledir,angleesq,vetcentrdir,vetcentresq,refgarraesq,refgarradir,idd,ied,mao_dir,mao_esq]=handmodelcalculation(f)
angledir=[];
angleesq=[];
vetcentrdir=[];
vetcentresq=[];
refgarraesq=[];
refgarradir=[];
bbasedir=[];
bbaseesq=[];
pd=[];
idd=[];
pe=[];
ied=[];
mao_dir=[];
mao_esq=[];
for i=1:4
baseposition=-f.pointables(i).direction*f.pointables(i).length;
baseposition=baseposition + f.pointables(i).position;
basepos(i)=baseposition(1);
end
z = [basepos(1) basepos(2) basepos(3) basepos(4)];
r = sort(z,'descend');
indicador_mao_direita = f.pointables(find(z==r(1)));
polegar_mao_direita = f.pointables(find(z==r(2)));
indicador_mao_esquerda = f.pointables(find(z==r(4)));
polegar_mao_esquerda = f.pointables(find(z==r(3)));
z = [f.hands(1).position(1) f.hands(2).position(1)];
r = sort(z,'descend');
mao_dir=f.hands(find(z==r(1)));
mao_esq=f.hands(find(z==r(2)));
id=indicador_mao_direita.position;
pd=polegar_mao_direita.position;
idd=mao_dir.yaw;
angledir=atan2(norm(cross(id,pd)), dot(id,pd));
angledir=rad2deg(angledir);
vetcentrdir=mao_dir.direction;
refgarradir=mao_dir.position;
ie=indicador_mao_esquerda.position;
pe=polegar_mao_esquerda.position;
ied=mao_esq.yaw;
angleesq=atan2(norm(cross(ie,pe)), dot(ie,pe));
angleesq=rad2deg(angleesq);
vetcentresq=mao_esq.direction;
refgarraesq=mao_esq.position;
end