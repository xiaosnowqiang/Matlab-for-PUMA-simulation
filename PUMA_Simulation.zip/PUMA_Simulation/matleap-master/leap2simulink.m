function [Posicaodir,Posicaoesq,Anglededosdir,Anglededosesq,vetcentrdir,vetcentresq,idd,ied]=leap2simulink
f=matleap_frame;
  if(length(f.hands) == 2 && (length(f.pointables)==4))
[posicao1,posicao2,anglededosdir,anglededosesq,Vetcentrdir,Vetcentresq,Idd,Ied,Mao_dir,Mao_esq]=print2(f);
    if Mao_dir.position(3)<110 && Mao_dir.position(1)<170
Posicaodir=posicao1;
Anglededosdir=anglededosdir;
vetcentrdir=Vetcentrdir;
idd=Idd;
elseif Mao_dir.position(3)>=110 || Mao_dir.position(1)>170
Posicaodir=zeros(1,3);
Anglededosdir=0;
vetcentrdir=zeros(1,3);
idd=zeros(1,3);
    end
if Mao_esq.position(3)<110 && Mao_esq.position(1)>-175
Posicaoesq=posicao2;
Anglededosesq=anglededosesq;
vetcentresq=Vetcentresq;
ied=Ied;
elseif Mao_esq.position(3)>=110 || Mao_esq.position(1)<-175
Posicaoesq=zeros(1,3);
Anglededosesq=0;
vetcentresq=zeros(1,3);
ied=zeros(1,3);
end
  else
Posicaodir=zeros(1,3);
Posicaoesq=zeros(1,3);
Anglededosdir=0;
Anglededosesq=0;
vetcentrdir=zeros(1,3);
vetcentresq=zeros(1,3);
idd=zeros(1,3);
ied=zeros(1,3);
  end
end