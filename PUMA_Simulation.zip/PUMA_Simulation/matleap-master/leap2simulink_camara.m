function [Posicao]=leap2simulink_camara
    f=matleap_frame;
     if (length(f.hands) == 1 &&(length(f.pointables)>=4&&length(f.pointables)<=5))
     Posicao=f.hands(1).position;
     else
     Posicao=zeros(1,3);
     end
      if (length(f.hands) == 2 &&(length(f.pointables)>=8&&length(f.pointables)<=10))
    z = [f.hands(1).position(1) f.hands(2).position(1)];
    r = sort(z,'descend');
    mao_dir=f.hands(find(z==r(1)));
    mao_esq=f.hands(find(z==r(2)));
    posicaodir=mao_dir.position(1);
    posicaoesq=mao_esq.position(1);
      else
    posicaodir=1000;
    posicaoesq=1000;
      end
end