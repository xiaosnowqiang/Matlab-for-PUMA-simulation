function matleap_debug
% MATLEAP_DEBUG Turn on matleap debug information output
matleap(-1);
