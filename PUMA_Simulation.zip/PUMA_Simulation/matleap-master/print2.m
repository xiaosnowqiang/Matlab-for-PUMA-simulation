function [posicao1,posicao2,anglededosdir,anglededosesq,Vetcentrdir,Vetcentresq,Idd,Ied,Mao_dir,Mao_esq]=print2(f)
[angledir,angleesq,vetcentrdir,vetcentresq,refgarraesq,refgarradir,idd,ied,mao_dir,mao_esq]=handmodelcalculation(f);
anglededosdir=angledir;
anglededosesq=angleesq;
posicao1=refgarradir;
posicao2=refgarraesq;
Vetcentrdir=vetcentrdir;
Vetcentresq=vetcentresq;
Idd=idd;
Ied=ied;
Mao_dir=mao_dir;
Mao_esq=mao_esq;
end