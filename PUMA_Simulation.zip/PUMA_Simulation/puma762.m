%        theta  d        a        alpha    offset
L1 = Link([0     0           0        -pi/2    0],'standard');
L2 = Link([0     0.19        0.650    0        0],'standard');
L3 = Link([0     0           0        pi/2     0],'standard');
L4 = Link([0     0.600       0        -pi/2    0],'standard');
L5 = Link([0     0           0        pi/2     0],'standard');
L6 = Link([0     0           0        0        0],'standard');
robot=SerialLink([L1 L2 L3 L4 L5 L6],'name','PUMA 762');
% theta=[-pi/2 -pi/2 pi/2 0 0 0];
% starobot.display();
% figure(3)
% robot.plot(theta);
figure(3)
teach(robot);
%% ����֪��������DHֵ�Ǳ�׼�ġ�����ת���ɸĽ��͵�DH
robot        %�鿴��׼�͵�DH
mdh=MDH(robot)%תΪMDH

%%  ���������MDH���л����˽�ģ���ṹ����
%        theta  d        a        alpha    offset
L1 = Link([0     0           0        0    0],'modified');
L2 = Link([0     0.19        0        -pi/2        0],'modified');
L3 = Link([0     0           0.65     0    0],'modified');
L4 = Link([0     0.600       0        pi/2    0],'modified');
L5 = Link([0     0           0        -pi/2     0],'modified');
L6 = Link([0     0           0        pi/2        0],'modified');
robot=SerialLink([L1 L2 L3 L4 L5 L6],'name','PUMA 762');
theta=[-pi/2 -pi/2 pi/2 0 0 0];
%starobot.display();
figure(4)
robot.plot(theta);
teach(robot);
%this DH parameters are from the author PUMA simulation
T1=transl(0.6,0.7,0.8);
q1=robot.ikine(T1);
%% �����Ǵ�GUI�л�õ�DH���������Լ��õ���DH
%
%        theta  d        a        alpha    offset
L1 = Link([0     0           0        0         0],'modified');
L2 = Link([0     0.19        0        pi/2     0],'modified');
L3 = Link([0     0           0.65     0         0],'modified');
L4 = Link([0     0.600       0        pi/2      0],'modified');
L5 = Link([0     0           0        pi/2     0],'modified');
L6 = Link([0     0           0        -pi/2      0],'modified');
robotM=SerialLink([L1 L2 L3 L4 L5 L6],'name','PUMA 762');
theta=[-pi/2 -pi/2 pi/2 0 0 0];
%robotM.display();
figure(5)
robotM.plot(theta);
teach(robotM);
robotM
%% �������Criag���Լ��õ���DHֵ��ΪMDH
rdh=robotM.DH()  %��Ϊ��׼DH

%% GUI��DHֵ����еĲ�һ��
%        theta  d        a        alpha    offset
L1 = Link([0     0           0        -pi/2    0],'standard');
L2 = Link([0     0        0.650    0        0],'standard');
L3 = Link([0     0.19        0        pi/2     0],'standard');
L4 = Link([0     0.600       0        -pi/2    0],'standard');
L5 = Link([0     0           0        pi/2     0],'standard');
L6 = Link([0     0           0        0        0],'standard');
robot=SerialLink([L1 L2 L3 L4 L5 L6],'name','PUMA 762');
% theta=[-pi/2 -pi/2 pi/2 0 0 0];
% starobot.display();
% figure(3)
% robot.plot(theta);
figure(6)
teach(robot);

